package com.example.twitterish

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
