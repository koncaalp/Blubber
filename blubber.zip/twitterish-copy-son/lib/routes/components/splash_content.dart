import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SplashContent extends StatelessWidget {
  const SplashContent({
    required this.text,
    required this.image,
  }) : super();
  final String text, image;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image(
            width: MediaQuery.of(context).size.width / 3,
            height: MediaQuery.of(context).size.height / 3,
            image: AssetImage(image),
          ),
          Text(
            text,
            style: GoogleFonts.montserrat(
              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }
}
