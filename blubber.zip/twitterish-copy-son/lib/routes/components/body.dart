import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twitterish/routes/WelcomePage.dart';
import 'dart:async';
import 'package:twitterish/routes/components/splash_content.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/dimensions.dart';
import 'package:twitterish/utils/styles.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

int currentPage = 0;

List<Map<String, String>> splashData = [
  {
    'text': 'Welcome to the Blubber! Lets take a walk!',
    'image': 'assets/icon.png'
  },
  {'text': 'Discover the latest topics!', 'image': 'assets/hashtag.png'},
  {
    'text': 'Search and connect with any user you want!',
    'image': 'assets/search_icon.png'
  },
];

class _BodyState extends State<Body> {
  /*
  Future checkFirstSeen() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool _seen = (prefs.getBool('seen') ?? false);
    if (_seen) {
      /*Navigator.push(
        context,
        new MaterialPageRoute(builder: (context) => new WelcomePage()),
      );*/
      Navigator.popAndPushNamed(context, 'WelcomePage.dart');
    } else {
      await prefs.setBool('seen', true);
      Navigator.pushNamed(context, 'WalkThroughPage.dart');
    }
  }
*/
  setPref() async {
    var prefs = await SharedPreferences.getInstance();
    await prefs.setInt('init', 2);
  }
  @override
  void initState() {
    super.initState();
    setPref();
  }


  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          flex: 3,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(Dimensions.largeMargin, 0, 0, 0),
            child: PageView.builder(
              onPageChanged: (value) {
                setState(() {
                  currentPage = value;
                });
              },
              itemCount: splashData.length,
              itemBuilder: (context, index) => SplashContent(
                text: splashData[index]['text']!,
                image: splashData[index]['image']!,
              ),
            ),
          ),
        ),
        Expanded(
          flex: 2,
          child: Padding(
            padding: const EdgeInsets.only(
                right: Dimensions.largeMargin, left: Dimensions.largeMargin),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    splashData.length,
                    (index) => buildDot(index: index),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height / 8,
                ),
                DefaultButton(
                  currentPage: currentPage,
                  text: 'Continue',
                  press: () {
                    Navigator.pushNamed(context, '/WelcomePage.dart');
                  },
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  AnimatedContainer buildDot({required int index}) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 320),
      margin: EdgeInsets.only(right: Dimensions.smallMargin),
      height: 6,
      width: currentPage == index ? 20 : 6,
      decoration: BoxDecoration(
        color: currentPage == index ? AppColors.primaryColor : AppColors.dots,
        borderRadius: BorderRadius.circular(3),
      ),
    );
  }
}

class DefaultButton extends StatefulWidget {
  const DefaultButton(
      {required this.text, required this.press, required this.currentPage})
      : super();
  final String text;
  final void Function()? press;
  final int currentPage;

  @override
  _DefaultButtonState createState() => _DefaultButtonState();
}

class _DefaultButtonState extends State<DefaultButton> {
  @override
  Widget build(BuildContext context) {
    if (widget.currentPage == splashData.length - 1) {
      return SizedBox(
        width: double.infinity,
        height: MediaQuery.of(context).size.height / 14,
        child: ElevatedButton(
          style: ButtonStyle(
            shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(Dimensions.borderRadius),
              ),
            ),
            backgroundColor: MaterialStateProperty.all<Color>(
              AppColors.primaryColor,
            ),
          ),
          onPressed: widget.press,
          child: Text(
            widget.text,
            style: whiteheader,
          ),
        ),
      );
    } else {
      return SizedBox();
    }
  }
}
