import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twitterish/routes/WelcomePage.dart';
import 'package:twitterish/routes/notifications.dart';
import 'package:twitterish/routes/searchexplore.dart';
import 'package:twitterish/services/auth.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/post.dart';
import 'package:twitterish/UI/post_tile.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:twitterish/utils/search.dart';

import 'UserProfilePage.dart';



_sendAnalyticsEvent() async {
  FirebaseAnalytics analytics = FirebaseAnalytics();

  await analytics.logEvent(
    name: "Login",
    parameters: <String, dynamic>{'login': 'logged'},
  );
}

class FeedPage extends StatefulWidget {
  const FeedPage({Key? key, required this.analytics, required this.observer}) : super(key: key);
  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {

  List<dynamic> posts = [];
  List<dynamic> following = [];
  FirebaseAuth _auth = FirebaseAuth.instance;
  AuthService ath = AuthService();
  FirebaseFirestore db = FirebaseFirestore.instance;


  void _loadFeed() async {
    posts = [];
    FirebaseAuth _auth;
    User? _user;
    _auth = FirebaseAuth.instance;
    _user = _auth.currentUser;
    print(_user.toString());
    if (_user != null) {
      print("c  ${_user.uid}");
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: _user.uid)
          .get();
      following = all.docs[0]['following'];
      print("t ${following[0]}");
    }

    var feed_post = await FirebaseFirestore.instance
        .collection('posts')
        .where('uid', whereIn: following)
        .get();
    print("d");
    feed_post.docs.forEach((doc) =>
    {
      print("b"),
      if (doc['active'] == "active") {
        print ("a"),
        posts.add(
            Post(
              username: doc['username'],
              userid: doc['uid'],
              postPhoto: doc['postPhoto'],
              text: doc['text'],
              date: doc['date'],
              likes: doc['likes'],
              comments: doc['comments'],
              topics: doc['topics'],
              isLiked: doc['likes'].contains(_user!.uid) ? true : false,
              likeCt: doc['likes'].length,
              active: doc['active'],
              postid: doc.id,
            )
        )
      }
    });
  }
  Future getUserDetails() async {
    User? _user = await _auth.currentUser;
    print(_user.toString());
    if (_user != null) {
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: _user.uid)
          .get();
      print("ca");
      username = all.docs[0]['username'];
      uid = _user.uid;
      print(uid);
    }
  }


  void initState()  {
    super.initState() ;
     getUserDetails();
    print("init");
    _loadFeed();
  }
  String username = "a";
  String uid = "0";

final pc = PageController(initialPage: 0);

  @override
  Widget build(BuildContext context) {
    int _selectedIndex = 0;
    void _onItemTapped(int index) {
      setState(() {
        _selectedIndex = index;
        print(_selectedIndex);
      });

      if (_selectedIndex == 2) {
        pc.jumpToPage(1);
      }
      if (_selectedIndex == 3) {
        pc.jumpToPage(2);
      }
    }
      return PageView(
        controller: pc,
        children: [Scaffold(
          backgroundColor: Colors.black,
            //floatingActionButton: FloatingActionButton(child: Text('+'),onPressed: (){_loadFeed();},),//Navigator.pushNamed(context, 'createPost');},),
            floatingActionButton: FloatingActionButton(child: Text('+'),onPressed: (){Navigator.pushNamed(context, 'createPost');},),
            //floatingActionButton: FloatingActionButton(child: Text('+'),onPressed: (){ath.signOut();},),
            appBar: AppBar(
              leading: IconButton(icon: Icon(Icons.arrow_back), onPressed: (){ath.signOut();},),
              title: Text(
                'blubber',
                style: TextStyle(
                  color: AppColors.primaryColor,
                ),
              ),
            ),
            body: SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                  left: MediaQuery.of(context).size.width / 100,
                  right: MediaQuery.of(context).size.width / 100,
                ),
                child: Column(
                  children:
                  posts
                      .map((post) => PostTile(
                    post: post,
                    delete: () {

                      setState(() {
                        posts.remove(post);
                      });
                    },
                    incrementLike: () {
                      setState(() {
                        post.likeCt++;
                      });
                    },
                    editpost: () {

                    }, isEdit: false,
                    /*updateDB: (){
                      var collection = FirebaseFirestore.instance.collection('posts');

                      collection
                          .doc(post.postid) // <-- Doc ID where data should be updated.
                          .update({"likes" : FieldValue.arrayUnion([username])} );
                      setState(() {
                        post.likeCt++;
                      });
                    }*/

                  ))
                      .toList(),
                ),
              ),
            ),
            bottomNavigationBar: BottomNavigationBar(
              items: <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  label: '',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.search),
                  label: '',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.notifications),
                  label: '',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.person),
                  label: '',
                ),
              ],
              currentIndex: _selectedIndex,
              selectedItemColor: AppColors.primaryColor,
              onTap: _onItemTapped,
            ),
        ),
        SearchView(analytics: widget.analytics, observer: widget.observer),
        Notifications(analytics: widget.analytics, observer: widget.observer),
          ProfilePage(analytics: widget.analytics, observer: widget.observer, isOther: false,)
        ]
      );
    }

  }

