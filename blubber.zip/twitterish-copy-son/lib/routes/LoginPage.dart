import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:twitterish/routes/FeedPage.dart';
import 'package:twitterish/services/db.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/dimensions.dart';
import 'package:twitterish/utils/styles.dart';
import 'package:email_validator/email_validator.dart';
import 'dart:io' show Platform;
import 'package:google_sign_in/google_sign_in.dart';

//import 'package:google_sign_in/google_sign_in.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key, required this.analytics, required this.observer})
      : super(key: key);
  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  int count = 0;
  String token = "";
  String _message = "";
  String name = "";
  String surname = "";
  DBservice db = DBservice();

  FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> showAlertDialog(String title, String message) async {
    bool isIOS = Platform.isIOS;
    if (isIOS) {
      return showDialog(
        context: context,
        builder: (BuildContext context) {
          return CupertinoAlertDialog(
            title: Text(title),
            content: SingleChildScrollView(
              child: Text(message),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text(
                  'OK',
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text(
                  'Cancel',
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
              ),
            ],
          );
        },
      );
    } else {
      return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(title),
            content: SingleChildScrollView(
              child: Text(message),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text(
                  'OK',
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text(
                  'Cancel',
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
              ),
            ],
          );
        },
      );
    }
  }

  void setMessage(String message) {
    setState(() {
      _message = message;
    });
  }

  Future<User?> loginWithGoogle() async {
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

    // Obtain the auth details from the request
    final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;

    // Create a new credential
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth?.accessToken,
      idToken: googleAuth?.idToken,
    );

    // Once signed in, return the UserCredential
    UserCredential userCredential = await FirebaseAuth.instance.signInWithCredential(credential);
    User? user = userCredential.user;
    token = await FirebaseAuth.instance.currentUser!.getIdToken();
    //db.addUser("gmail", "surname", "email", token);
    return user;
  }







  Future<void> loginUser() async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      print(userCredential.toString());
      User? user = userCredential.user;
    } on FirebaseAuthException catch (e) {
      print(e.toString());
      if (e.code == 'user-not-found') {
        setMessage('User not found');
      } else if (e.code == 'wrong-password') {
        setMessage('Please check your password!');
      }
    }
  }

  Future<void> signUpUser() async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);
      db.addUser("$name $surname", email, userCredential.user!.uid, "$name$surname");
      print(userCredential.toString());
    } on FirebaseException catch (e) {
      print(e.toString());
      if (e.code == 'email-already-in-use') {
        setMessage('Email already exists!');
      } else if (e.code == 'weak-password') {
        setMessage('Weak password: add uppercase, lowercase, special char');
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _auth.authStateChanges().listen((event) {
      if (event == null) {
        print('User is signed out!');
      } else {
        print('User is signed in!');
      }
    });
  }
bool x = true;
  @override
  Widget build(BuildContext context) {
    _auth.authStateChanges().listen((event) {
      if (event == null) {
        setState(() {
          x = true;
        });
      } else {
        setState(() {
          x = false;
        });
      }
    }); if (x) {
      return Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/backgroundImage.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            body: SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    SizedBox(
                      height: 100,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: Text('Sign In', style: whiteboldheader),
                    ),
                    SizedBox(
                      height: Dimensions.textboxsizedbox,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: Dimensions.xlargeMargin,
                          right: Dimensions.xlargeMargin),
                      child: Column(
                        children: [
                          Container(
                            alignment: Alignment.centerLeft,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: 20,
                                ),
                                Text('Email', style: whitemedium),
                                SizedBox(
                                  height: Dimensions.textboxsizedbox,
                                ),
                                TextFormField(
                                  validator: (value) {
                                    if (value == null) {
                                      return 'Email field can not be empty!';
                                    } else {
                                      String trimmedValue = value.trim();
                                      if (trimmedValue.isEmpty) {
                                        return 'Please enter email!';
                                      }
                                      if (!EmailValidator.validate(
                                          trimmedValue)) {
                                        return 'Please enter a valid email!';
                                      }
                                    }
                                    return null;
                                  },
                                  onSaved: (value) {
                                    if (value != null) {
                                      email = value;
                                    }
                                  },
                                  keyboardType: TextInputType.emailAddress,
                                  style: whiteregular,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderSide:
                                      BorderSide(color: AppColors.border),
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(Dimensions.borderRadius),
                                      ),
                                    ),
                                    contentPadding: EdgeInsets.only(
                                        top: Dimensions.regularMargin),
                                    prefixIcon: Icon(
                                      Icons.account_circle_outlined,
                                      color: AppColors.icon,
                                    ),
                                    hintText: 'Enter your email: ',
                                  ),
                                ),
                                SizedBox(
                                  height: Dimensions.textboxsizedbox,
                                ),
                                Text(
                                  'Password',
                                  style: whitemedium,
                                ),
                                SizedBox(
                                  height: Dimensions.textboxsizedbox,
                                ),
                                TextFormField(
                                  validator: (value) {
                                    if (value == null) {
                                      return 'Password field can not be empty!';
                                    } else {
                                      String trimmedValue = value.trim();
                                      if (trimmedValue.isEmpty) {
                                        return 'Password field can not be empty!';
                                      }
                                      if (trimmedValue.length < 8) {
                                        return 'Password must be longer than 8 characters!';
                                      }
                                    }
                                    return null;
                                  },
                                  onSaved: (value) {
                                    if (value != null) {
                                      password = value;
                                    }
                                  },
                                  keyboardType: TextInputType.name,
                                  style: whiteregular,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderSide:
                                      BorderSide(color: AppColors.border),
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(Dimensions.borderRadius),
                                      ),
                                    ),
                                    contentPadding: EdgeInsets.only(
                                        top: Dimensions.regularMargin),
                                    prefixIcon: Icon(
                                      Icons.lock,
                                      color: AppColors.icon,
                                    ),
                                    hintText: 'Enter your password: ',
                                  ),
                                ),
                                SizedBox(
                                  height: Dimensions.textboxsizedbox,
                                ),
                                SizedBox(
                                  width: MediaQuery.of(context).size.width,
                                  child: ElevatedButton(
                                    onPressed: () {
                                      if (_formKey.currentState!.validate()) {
                                        _formKey.currentState!.save();
                                        //
                                        //signUpUser();
                                        loginUser();
                                        print('Mail: ' +
                                            email +
                                            ' Password: ' +
                                            password);
                                      } else {
                                        setState(() {
                                          count++;
                                        });
                                      }
                                      if (count >= 3) {
                                        showAlertDialog(
                                          'Alert',
                                          'You have tried $count many times!',
                                        );
                                      }
                                    },
                                    child: Text('Login'),
                                    style: ButtonStyle(
                                      shape: MaterialStateProperty.all<
                                          RoundedRectangleBorder>(
                                        RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              Dimensions.borderRadius),
                                        ),
                                      ),
                                      backgroundColor:
                                      MaterialStateProperty.all<Color>(
                                        AppColors.dirtybackground,
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  _message,
                                  style: TextStyle(color: Colors.red),
                                ),
                                Container(
                                  alignment: Alignment.center,
                                  child: Column(
                                    children: [
                                      Text('- OR -', style: whitemedium),
                                      SizedBox(height: 5.0),
                                      Text(
                                        'Sing In with',
                                        //style: kLabelLightTextStyle,
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: Dimensions.textboxsizedbox),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceEvenly,
                                  children: <Widget>[
                                    GestureDetector(
                                      onTap: () => print('Sing In with Facebook'),
                                      child: Container(
                                        height: 40.0,
                                        width: 60.0,
                                        decoration: const BoxDecoration(
                                            shape: BoxShape.circle,
                                            boxShadow: [
                                              BoxShadow(
                                                color: AppColors.shadow,
                                                offset:
                                                Offset(0, Dimensions.offset),
                                                blurRadius: 6.0,
                                              ),
                                            ],
                                            image: DecorationImage(
                                                image: AssetImage(
                                                    'assets/fb.jpeg'))),
                                      ),
                                    ),
                                    GestureDetector(
                                      onTap: () { loginWithGoogle();

                                      },
                                      child: Container(
                                        height: 40.0,
                                        width: 60.0,
                                        decoration: const BoxDecoration(
                                            shape: BoxShape.circle,
                                            boxShadow: [
                                              BoxShadow(
                                                color: AppColors.shadow,
                                                offset:
                                                Offset(0, Dimensions.offset),
                                                blurRadius: 6.0,
                                              ),
                                            ],
                                            image: DecorationImage(
                                                image: AssetImage(
                                                    'assets/ggl.jpeg'))),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5.0),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: Dimensions.largeMargin * 1.5),
                                  child: SizedBox(
                                    width: double.infinity,
                                    height: 50,
                                    child: ElevatedButton(
                                      child: Text('CANCEL', style: mainbutton),
                                      style: ButtonStyle(
                                        shape: MaterialStateProperty.all<
                                            RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                Dimensions.borderRadius),
                                          ),
                                        ),
                                        backgroundColor:
                                        MaterialStateProperty.all<Color>(
                                          AppColors.dirtybackground,
                                        ),
                                      ),
                                      onPressed: () {
                                        Navigator.pushNamed(
                                            context, '/WelcomePage.dart');
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
      );
    }
    else {
      return FeedPage(analytics: widget.analytics, observer: widget.observer);
    }
  }
}


/*
import 'package:flutter/material.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/dimensions.dart';
import 'package:twitterish/utils/styles.dart';

class LoginDemo extends StatefulWidget {
  @override
  _LoginDemoState createState() => _LoginDemoState();
}

class _LoginDemoState extends State<LoginDemo> {
  bool rememberMe = false;

  Widget buildEmail() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          'Email',
          style: TextStyle(),
        ),
        SizedBox(height: Dimensions.textboxsizedbox),
        Container(
          alignment: Alignment.centerLeft,
          //decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextField(
            keyboardType: TextInputType.emailAddress,
            style: whiteregular,
            decoration: InputDecoration(
              //labelStyle: kLabelLightTextStyle,
              border: OutlineInputBorder(
                borderSide: BorderSide(color: AppColors.border),
                borderRadius:
                    BorderRadius.all(Radius.circular(Dimensions.borderRadius)),
              ),
              contentPadding: EdgeInsets.only(top: Dimensions.regularMargin),
              prefixIcon: Icon(
                Icons.email,
                color: AppColors.icon,
              ),
              hintText: 'Enter your Email',
            ),
          ),
        )
      ],
    );
  }

  Widget buildpassword() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          'Password',
          style: TextStyle(),
        ),
        SizedBox(height: Dimensions.textboxsizedbox),
        Container(
          alignment: Alignment.centerLeft,
          height: 60.0,
          child: TextField(
            obscureText: true,
            style: whiteregular,
            decoration: InputDecoration(
              labelStyle: TextStyle(),
              //border: new Border.all(color: Colors.white,width: 30.0,) ,
              border: OutlineInputBorder(
                borderSide: BorderSide(color: AppColors.border),
                borderRadius:
                    BorderRadius.all(Radius.circular(Dimensions.borderRadius)),
              ),

              contentPadding: EdgeInsets.only(top: Dimensions.regularMargin),
              prefixIcon: Icon(
                Icons.lock,
                color: AppColors.icon,
              ),
              hintText: 'Enter your Password',
            ),
          ),
        )
      ],
    );
  }

  Widget buildForgotPassword() {
    return Container(
      alignment: Alignment.centerRight,
      child: FlatButton(
        onPressed: () => print('Forgot Password Button Pressed'),
        child: Text(
          'Forgot Password',
          style: TextStyle(),
        ),
        padding: EdgeInsets.only(right: 0.0),
      ),
    );
  }

  Widget buildRememberMe() {
    return Container(
        height: 20,
        child: Row(
          children: <Widget>[
            Theme(
                data:
                    ThemeData(unselectedWidgetColor: AppColors.secondaryColor),
                child: Checkbox(
                  value: rememberMe,
                  checkColor: AppColors.success,
                  activeColor: AppColors.secondaryColor,
                  onChanged: (value) {
                    setState(() {
                      rememberMe != value;
                    });
                  },
                )),
            Text(
              'Remember Me',
              style: TextStyle(),
            ),
          ],
        ));
  }

  Widget buildLoginButton() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: Dimensions.largeMargin),
        width: double.infinity,
        child: RaisedButton(
          elevation: 5.0,
          onPressed: () => print('Login Button Pressed'),
          padding: EdgeInsets.all(Dimensions.regularMargin),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Dimensions.borderRadius),
          ),
          color: AppColors.border,
          child: Text(
            'LOGIN',
            style: mainbutton,
          ),
        ));
  }

  Widget buildSignInWithText() {
    return Column(
      children: <Widget>[
        Text(
          '- OR -',
          style: whitemedium,
        ),
        SizedBox(height: 20.0),
        Text(
          'Sıgn In With',
          style: whitemedium, // buralar değişecek
        )
      ],
    );
  }

  Widget buildFacebookLogin() {
    return GestureDetector(
      onTap: () => print('Login with Facebook'),
      child: Container(
        height: 60.0,
        width: 60.0,
        decoration: const BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: AppColors.shadow,
                offset: Offset(0, Dimensions.offset),
                blurRadius: 6.0,
              ),
            ],
            image: DecorationImage(image: AssetImage('assets/fb.jpeg'))),
      ),
    );
  }

  Widget buildGoogleLogin() {
    return GestureDetector(
      onTap: () => print('Login with Google'),
      child: Container(
        height: 60.0,
        width: 60.0,
        decoration: const BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: AppColors.shadow,
                offset: Offset(0, Dimensions.offset),
                blurRadius: 6.0,
              ),
            ],
            image: DecorationImage(image: AssetImage('assets/ggl.jpeg'))),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/backgroundImage.jpeg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            height: double.infinity,
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(
                horizontal: Dimensions.xlargeMargin,
                vertical: Dimensions.xlargeMargin,
              ),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(height: 50.0),
                    Text(
                      'Sign In',
                      style: whiteboldheader,
                    ),
                    SizedBox(height: 30.0),
                    buildEmail(),
                    SizedBox(height: 30.0),
                    buildpassword(),
                    buildForgotPassword(),
                    SizedBox(height: 30.0),
                    buildRememberMe(),
                    buildLoginButton(),
                    buildSignInWithText(),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: Dimensions.largeMargin),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          GestureDetector(
                            onTap: () => print('Login with Facebook'),
                            child: Container(
                              height: 40.0,
                              width: 60.0,
                              decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.shadow,
                                      offset: Offset(0, Dimensions.offset),
                                      blurRadius: 6.0,
                                    ),
                                  ],
                                  image: DecorationImage(
                                      image: AssetImage('assets/fb.jpeg'))),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => print('Login with Google'),
                            child: Container(
                              height: 40.0,
                              width: 60.0,
                              decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.shadow,
                                      offset: Offset(0, Dimensions.offset),
                                      blurRadius: 6.0,
                                    ),
                                  ],
                                  image: DecorationImage(
                                      image: AssetImage('assets/ggl.jpeg'))),
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () =>
                          Navigator.pushNamed(context, 'SignupPage.dart'),
                      child: RichText(
                          text: TextSpan(children: [
                        TextSpan(
                            text: 'Dont Have an Account ? ',
                            style: whitemedium),
                        TextSpan(text: ' Sign Up', style: whiteboldmedium),
                      ])),
                    ),
                  ]),
            ),
          )
        ],
      ),
    );
  }
}
*/