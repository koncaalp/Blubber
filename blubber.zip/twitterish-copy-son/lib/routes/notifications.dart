import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:twitterish/UI/notif_tile.dart';
import 'package:twitterish/services/auth.dart';
import 'package:twitterish/utils/notifs.dart';
import 'package:firebase_core/firebase_core.dart';

class Notifications extends StatefulWidget {
  const Notifications(
      {Key? key, required this.analytics, required this.observer})
      : super(key: key);
  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;
  @override
  State<Notifications> createState() => _NotificationsState();
}
FirebaseAuth _auth = FirebaseAuth.instance;
String username = "a";
dynamic uid = "";
AuthService ath = AuthService();
FirebaseFirestore db = FirebaseFirestore.instance;
List<Notif> myNotifs = [];

Future getUserDetails() async {
  User? _user = await _auth.currentUser;
  print(_user.toString());
  if (_user != null) {
    var all = await FirebaseFirestore.instance
        .collection('users')
        .where('uid', isEqualTo: _user.uid)
        .get();
    print("ca");
    username = all.docs[0]['username'];
     uid = _user.uid;
    print(username);
  }
}

void _loadNotif() async {
  myNotifs = [];
  FirebaseAuth _auth;
  User? _user;
  _auth = FirebaseAuth.instance;
  _user = _auth.currentUser;
  print(_user.toString());
  await getUserDetails();
  var feed_post = await FirebaseFirestore.instance
      .collection('notifications')
      .where('ruid', isEqualTo: uid)
      .get();
  print("d");
  print(myNotifs.length);
  print(feed_post.size);
  feed_post.docs.forEach((doc) =>
  {

      //if(!myNotifs.contains(Notif(date: doc['date'], ruid: doc['ruid'], suid: doc['suid'], type: doc['type'], username: doc['username'], content: doc['content'], notifid: doc.id)))
    if(feed_post.size != myNotifs.length)
    {
      print(myNotifs.length),

      print ("notif"),
          myNotifs.add(
              Notif(
                username: doc['username'],
                ruid: doc['ruid'],
                suid: doc['suid'],
                content: doc['content'],
                date: doc['date'],
                type: doc['type'],
                notifid: doc.id,
              )
          )
        }

  });
}
class _NotificationsState extends State<Notifications> {
  /*List<Notif> myNotifs = []; [
    Notif(
      type: "like",
      title: "Liked your Blub",
      content: 'I love Blubber',
      date: '22.10.2021',
      username: "alpkonca",
    ),
    Notif(
      type: "comment",
      title: "Commented on your Blub",
      content: 'Me too',
      date: '22.10.2021',
      username: "burak",
    ),
    Notif(
      type: "reblub",
      title: "Reblubbed",
      content: 'I love Blubber',
      date: '22.10.2021',
      username: "alpkonca",
    ),
    Notif(
      type: "like",
      title: "Liked your Blub",
      content: 'I have Blubber',
      date: '22.10.2021',
      username: "burak",
    ),
    Notif(
      type: "like",
      title: "Liked your Blub",
      content: 'I have Blubber',
      date: '22.10.2021',
      username: "burak",
    ),
    Notif(
      type: "like",
      title: "Liked your Blub",
      content: 'I have Blubber',
      date: '22.10.2021',
      username: "burak",
    ),
    Notif(
      type: "like",
      title: "Liked your Blub",
      content: 'I have Blubber',
      date: '22.10.2021',
      username: "burak",
    ),
    Notif(
      type: "like",
      title: "Liked your Blub",
      content: 'I have Blubber',
      date: '22.10.2021',
      username: "burak",
    ),
  ];*/
  int _selectedIndex = 2;
  Future<void> _setCurrentScreen() async {
    await widget.analytics.setCurrentScreen(screenName: "Notifications");
    print("succeed");
  }


  void initState() {
    super.initState();
     getUserDetails();
    print("init");
    _loadNotif();
  }
  @override
  Widget build(BuildContext context) {

    /*MediaQueryData _mediaQueryData;
    double screenWidth;
    double screenHeight;
    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height; */
    return Scaffold(

            appBar: PreferredSize(
                preferredSize: Size.fromHeight(30.0),
                child: AppBar(
                    backgroundColor: Colors.transparent,
                    centerTitle: true,
                    title: Text("Notifications",
                        style: TextStyle(color: Colors.white)))),
            backgroundColor: Colors.black,
            body: SingleChildScrollView(
              child: Column(
                children: [
                  Divider(
                    color: Colors.lightBlueAccent,
                    thickness: 1,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: myNotifs
                          .map((notif) => NotifTile(
                                notif: notif,
                                delete: () {
                                  setState(() {
                                    myNotifs.remove(notif);
                                  });
                                },
                              ))
                          .toList(),
                    ),
                  ),
                ],
              ),
            ));
  }
}
