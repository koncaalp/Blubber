import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:twitterish/routes/FeedPage.dart';
import 'package:twitterish/services/auth.dart';
import 'package:twitterish/services/db.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:path/path.dart';
import 'dart:io';

class EditPost extends StatefulWidget {
  final String postid;
  const EditPost({Key? key, required this.postid}) : super(key: key);

  @override
  _EditPostState createState() => _EditPostState();
}

class _EditPostState extends State<EditPost> {
  final _formKey = GlobalKey<FormState>();

  final ImagePicker _picker = ImagePicker();
  DBservice db = DBservice();
  AuthService ath = AuthService();
  FirebaseAuth _auth = FirebaseAuth.instance;

  XFile? _image;

  Future pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _image = pickedFile;
    });
  }

  Future uploadImageToFirebase(BuildContext context) async {
    String fileName = basename(_image!.path);
    print(_image!.path);
    Reference firebaseStorageRef = FirebaseStorage.instance.ref().child(
        'uploads/$fileName');
    try {
      await firebaseStorageRef.putFile(File(_image!.path));
      print("Upload complete");
      setState(() {
        _image = null;
      });
    } on FirebaseException catch (e) {
      print('ERROR: ${e.code} - ${e.message}');
    } catch (e) {
      print(e.toString());
    }
  }

  String username = "a";
  String uid = "0";

  Future getUserDetails() async {
    User? _user = await _auth.currentUser;
    print(_user.toString());
    if (_user != null) {
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: _user.uid)
          .get();
      print("ca");
      username = all.docs[0]['username'];
      uid = _user.uid;
      print(uid);
    }
  }

  final myController = TextEditingController();
  final myController2 = TextEditingController();

  bool x = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        body: Column(
          children: [
            SizedBox(height: 60,),
            Divider(
              height: 40, color: AppColors.primaryColor, thickness: 3,),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Text("Create Post", style: TextStyle(color: Colors.white),)
              ],

            ),
            Divider(
              height: 40, color: AppColors.primaryColor, thickness: 3,),
            SizedBox(height: 10,),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                //height: 150,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    border: Border.all(
                        width: 1, color: AppColors.primaryColor)),
                child: Form(
                  key: _formKey,
                  child: TextFormField(
                    style: TextStyle(color: Colors.white),

                    controller: myController2,
                    maxLines: 6,
                  ),
                ),
              ),
            ),


            Row(mainAxisAlignment: MainAxisAlignment.center,
              children: [IconButton(
                icon: Icon(Icons.clear, color: Colors.white,),
                onPressed: () async {
                  await getUserDetails();
                  print("b $username");
                  if (_image != null) {
                    uploadImageToFirebase(context);
                    await FirebaseFirestore.instance
                        .collection('posts')
                        .doc(widget.postid)
                        .update(
                        {'text': myController.text, 'postPhoto': _image!.name});
                    //return FeedPage(analytics: widget.analytics, observer: widget.observer);

                    Navigator.pop(context);
                  }
                  else {
                    print(username);
                    await FirebaseFirestore.instance
                        .collection('posts')
                        .doc(widget.postid)
                        .update(
                        {'text': myController.text, 'postPhoto': _image!.name});
                  }
                  Navigator.pop(context);
                },),
              ],),
            Expanded(
              child: Stack(
                children: [
                  Container(
                    height: 80,
                    margin: EdgeInsets.only(left: 30, right: 30, top: 10),
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(30),
                        child: _image != null
                            ? Image.file(File(_image!.path)) : TextButton(
                          child: Icon(
                            Icons.add_a_photo,
                            size: 40,
                          ),
                          onPressed: pickImage,
                        )
                    ),
                  )
                ],
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [


                if(_image != null) OutlinedButton(
                  onPressed: () {
                    setState(() {
                      _image = null;
                    });
                  },
                  child: Text('Cancel'),
                ),
              ],
            )
          ],
        )
    );
  }
}
