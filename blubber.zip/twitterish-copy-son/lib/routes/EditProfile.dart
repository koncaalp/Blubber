import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:twitterish/routes/FeedPage.dart';
import 'package:twitterish/services/auth.dart';
import 'package:twitterish/services/db.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:path/path.dart';
import 'dart:io';

class EditProfilePage extends StatefulWidget {
  String uid;

   EditProfilePage(
      {Key? key, required this.analytics, required this.observer, required this.uid,})
      : super(key: key);
  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final ImagePicker _picker = ImagePicker();
  DBservice db = DBservice();
  AuthService ath = AuthService();

  XFile? _image;

  Future pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _image = pickedFile;
    });
  }

  Future uploadImageToFirebase(BuildContext context) async {
    String fileName = basename(_image!.path);
    print(_image!.path);
    Reference firebaseStorageRef = FirebaseStorage.instance.ref().child(
        'uploads/$fileName');
    try {
      await firebaseStorageRef.putFile(File(_image!.path));
      print("Upload complete");
      setState(() {
        _image = null;
      });
    } on FirebaseException catch (e) {
      print('ERROR: ${e.code} - ${e.message}');
    } catch (e) {
      print(e.toString());
    }
  }
  String cfullname = "a",
      cusername = "a",
      activation = "active",
      cuid = "a",
      cemail = "a",
      cphoto =  'https://images.genius.com/a327ce18ee763752ef342d874a1ba07c.300x300x1.jpg',
      curl1 = 'https://images.genius.com/a327ce18ee763752ef342d874a1ba07c.300x300x1.jpg',
      cbio = "No bio";
      bool isPrivDia = true;
  List cfollowers = ["a"],
      cfollowing = ["a"];
  Future getcurrUserDetails() async {
    User? _user = await _auth.currentUser;
    print(_user.toString());
    if (_user != null) {
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: widget.uid)
          .get();
      print("ca");
      setState(() {
        cusername = all.docs[0]['username'];
        cuid = _user.uid;
        cfullname = all.docs[0]['fullname'];
        cemail = all.docs[0]['email'];
        cphoto = all.docs[0]['userPhoto'];
        cfollowers = all.docs[0]['followers'];
        cfollowing = all.docs[0]['following'];
        cbio = all.docs[0]['bio'];
        isPrivDia = all.docs[0]['isPriv'];
        activation = all.docs[0]['active'];
      });


    }
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getcurrUserDetails();
  }
 TextEditingController myController = TextEditingController();
  TextEditingController myController2 = TextEditingController();

  @override
  Widget build(BuildContext context) =>  Scaffold(

    body: SingleChildScrollView(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 90),Text("Bio: ", style: TextStyle(color: Colors.white),),
            TextField(
              controller: myController,
            ),
            SizedBox(height: 20),Text("Username: ", style: TextStyle(color: Colors.white),),
            TextField(
              controller: myController2,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Private Account", style: TextStyle(color: Colors.white)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Switch(
                  value:  isPrivDia,
                  onChanged: (value) {
                    setState(() {
                      isPrivDia = value;
                      print(isPrivDia);
                    });
                  }

              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Disable account",style: TextStyle(color: Colors.white)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(
                onPressed: (){
                  setState(() {
                    activation = "no";
                    print(activation);
                  });
                },
                child: Text("Disable",style: TextStyle(color: Colors.white)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("Enable account",style: TextStyle(color: Colors.white)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(
                onPressed: (){
                  setState(() {
                    activation = "active";

                  });
                },
                child: Text("Enable",style: TextStyle(color: Colors.white)),
              ),
            ),
            Stack(
                children: [
                  Container(
                    height: 80,
                    margin: EdgeInsets.only(left: 30, right: 30, top: 10),
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(30),
                        child: _image != null
                            ? Image.file(File(_image!.path)) : TextButton(
                          child: Icon(
                            Icons.add_a_photo,
                            size: 40,
                          ),
                          onPressed: pickImage,
                        )
                    ),
                  )
                ],
              ),


            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [


                if(_image != null) OutlinedButton(
                  onPressed: () {
                    setState(() {
                      _image = null;
                    });
                  },
                  child: Text('Cancel'),
                ),
              ],
            ),
            ElevatedButton(onPressed: () async {
              print(cuid);
              print(isPrivDia);
              await FirebaseFirestore.instance
                  .collection('users')
                  .doc(cuid)
                  .update(
                  {'isPriv': isPrivDia});
              await FirebaseFirestore.instance
                  .collection('users')
                  .doc(cuid)
                  .update(
                  {'active': activation});
              await FirebaseFirestore.instance
                  .collection('users')
                  .doc(cuid)
                  .update(
                  {'bio': myController.text});
              await FirebaseFirestore.instance
                  .collection('users')
                  .doc(cuid)
                  .update(
                  {'username': myController2.text});
              await uploadImageToFirebase(context);
              if(_image!= null){
                await FirebaseFirestore.instance
                    .collection('users')
                    .doc(cuid)
                    .update(
                    {'userPhoto': _image?.name});
              }

              Navigator.of(context, rootNavigator: true).pop('dialog');
            }, child: Text("Save", style: TextStyle(color: Colors.white),))
          ],
        ),
      ),
    ),

  );
}
