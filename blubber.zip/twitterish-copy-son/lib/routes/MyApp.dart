import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twitterish/routes/EditProfile.dart';
import 'package:twitterish/routes/FeedPage.dart';
import 'package:twitterish/routes/LoginPage.dart';
import 'package:twitterish/routes/SignupPage.dart';
import 'package:twitterish/routes/UserProfilePage.dart';
import 'package:twitterish/routes/WalkThroughPage.dart';
import 'package:twitterish/routes/WelcomePage.dart';
import 'package:twitterish/routes/notifications.dart';
import 'package:twitterish/routes/searchexplore.dart';

import 'create_post.dart';

class MyApp extends StatefulWidget {
  final bool ifFirst;
  const MyApp({Key? key, required this.ifFirst}) : super(key: key);
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return MaterialApp(
            home: Scaffold(
              body: Center(
                child: Text('No Connection!'),
              ),
            ),
          );
        }
        if (snapshot.connectionState == ConnectionState.done) {
          print('Firebase Connected!');
          return ConnectedFirebase(ifFirst: widget.ifFirst,);
        }
        return MaterialApp(
          home: Scaffold(
            body: Center(
              child: Text('Connecting to firebase...'),
            ),
          ),
        );
      },
    );
  }
}


class ConnectedFirebase extends StatefulWidget {
  final bool ifFirst;

  const ConnectedFirebase({
    Key? key, required this.ifFirst
  }) : super(key: key);

  static FirebaseAnalytics analytics = FirebaseAnalytics();
  static FirebaseAnalyticsObserver observer =
      FirebaseAnalyticsObserver(analytics: analytics);

  @override
  State<ConnectedFirebase> createState() => _ConnectedFirebaseState();

}

class _ConnectedFirebaseState extends State<ConnectedFirebase> {
  int init = 1;


  getPref() async {
    var pref = await SharedPreferences.getInstance();
    init = await pref.getInt('init') ?? 1;

  }
  void getPref2() {
    getPref().then((value) {
      setState(() {
        init = value;
      });
    });
  }
  void initState() {
    super.initState();
    getPref2();
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorObservers: <NavigatorObserver>[ConnectedFirebase.observer],
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home:
      widget.ifFirst ? WalkThroughPage(
        analytics: ConnectedFirebase.analytics,
        observer: ConnectedFirebase.observer,
      ) : WelcomePage(analytics: ConnectedFirebase.analytics, observer: ConnectedFirebase.observer),


      routes: {
        '/Profile.dart': (context) => ProfilePage(
              analytics: ConnectedFirebase.analytics,
              observer: ConnectedFirebase.observer, isOther: false,
            ),
        '/EditProfile.dart': (context) => EditProfilePage(
              analytics: ConnectedFirebase.analytics,
              observer: ConnectedFirebase.observer, uid: 'active',
            ),
        '/Search.dart': (context) => SearchView(
              analytics: ConnectedFirebase.analytics,
              observer: ConnectedFirebase.observer,
            ),
        '/Notifications.dart': (context) => Notifications(
              analytics: ConnectedFirebase.analytics,
              observer: ConnectedFirebase.observer,
            ),
        '/FeedPage.dart': (context) => FeedPage(analytics: ConnectedFirebase.analytics,
          observer: ConnectedFirebase.observer,),
        '/WalkThroughPage.dart': (context) => WalkThroughPage(
              analytics: ConnectedFirebase.analytics,
              observer: ConnectedFirebase.observer,
            ),
        '/WelcomePage.dart': (context) => WelcomePage(
              analytics: ConnectedFirebase.analytics,
              observer: ConnectedFirebase.observer,
            ),
        'SignupPage.dart': (context) => SignupPage(
              analytics: ConnectedFirebase.analytics,
              observer: ConnectedFirebase.observer,
            ),
        'LoginPage.dart': (context) => LoginPage(
              analytics: ConnectedFirebase.analytics,
              observer: ConnectedFirebase.observer,
            ),
        'createPost': (context) => createPost(
          analytics: ConnectedFirebase.analytics,
          observer: ConnectedFirebase.observer,
        ),
      },
    );
  }
}
