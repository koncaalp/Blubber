import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:flutter/material.dart';
import 'package:twitterish/routes/components/body.dart';

class WalkThroughPage extends StatelessWidget {
  const WalkThroughPage(
      {Key? key, required this.analytics, required this.observer})
      : super(key: key);
  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Body());
  }
}
