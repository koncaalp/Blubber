import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:twitterish/routes/FeedPage.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/dimensions.dart';
import 'package:twitterish/utils/styles.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({Key? key, required this.analytics, required this.observer})
      : super(key: key);
  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  bool x = false;
  @override
  Widget build(BuildContext context) {
    MediaQueryData _mediaQueryData;
    double screenWidth;
    double screenHeight;
    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height;

    _auth.authStateChanges().listen((event) {
      if (event == null) {
        setState(() {
          x = true;
        });
      } else {
        setState(() {
          x = false;
        });
      }
    });

    if (x) {
      return Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/backgroundImage.jpeg"),
                fit: BoxFit.cover),
          ),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              elevation: 0,
              backgroundColor: Colors.transparent,
            ),
            body: Column(
              children: [
                SizedBox(
                  height: screenHeight / 10,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: screenHeight / 32,
                    ),
                    Image(
                      image: AssetImage("assets/logo.png"),
                      height: screenHeight / 11,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          Dimensions.regularMargin, 0, 0, 0),
                      child: Text("Blubber", style: whiteboldmedium),
                    )
                  ],
                ),
                SizedBox(
                  height: screenHeight / 32,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: screenHeight / 24,
                    ),
                    Container(
                        width: screenWidth / 1.2,
                        child: Text(
                            "Start Blubbing With People All Around The World Now",
                            style: catchphrase)),
                  ],
                ),
                Row(
                  children: [
                    SizedBox(
                      height: screenHeight / 6,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(
                      width: screenWidth / 4,
                    ),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(0, 0,
                            Dimensions.regularMargin, Dimensions.regularMargin),
                        child: Text(
                          "Log in to Blubber",
                          style: whiteboldmedium,
                        )),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(0, 0,
                            Dimensions.largeMargin, Dimensions.regularMargin),
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pushNamed(context, 'LoginPage.dart');
                          },
                          child: Icon(Icons.arrow_forward_ios_rounded,
                              color: AppColors.primaryColor),
                          style: ElevatedButton.styleFrom(
                            primary: AppColors.icon,
                          ),
                        ))
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(
                      width: screenWidth / 2,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          0, 0, Dimensions.regularMargin, 0),
                      child: Text("Sign Up", style: whiteboldmedium),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                          0, 0, Dimensions.largeMargin, 0),
                      child: OutlinedButton(
                        onPressed: () {
                          Navigator.pushNamed(context, 'SignupPage.dart');
                        },
                        child: Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: AppColors.icon,
                        ),
                        style: OutlinedButton.styleFrom(
                          primary: Colors.transparent,
                          side: BorderSide(
                              width: Dimensions.borderWidth,
                              color: AppColors.border),
                          shadowColor: Colors.transparent,
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
      );
    } else {
      return FeedPage(analytics: widget.analytics,
        observer: widget.observer,);
    }
  }
}

void buttonPressed() {
  print('button pressed!');
}
