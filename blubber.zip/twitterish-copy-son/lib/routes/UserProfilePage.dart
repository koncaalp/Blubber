import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:twitterish/UI/user_post_tile.dart';
import 'package:twitterish/routes/EditProfile.dart';
import 'package:twitterish/routes/MyApp.dart';
import 'package:twitterish/services/db.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/user_preferences.dart';
import 'package:twitterish/routes/components/profile_widget.dart';
import 'package:twitterish/utils/user.dart';
import 'package:twitterish/routes/components//numbers_widget.dart';
import 'package:twitterish/utils/post.dart';
import 'package:twitterish/UI/post_tile.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';

class ProfilePage extends StatefulWidget {
   ProfilePage({Key? key, required this.analytics, required this.observer, required this.isOther, this.userid})
      : super(key: key);
  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;
  final bool isOther;
  String? userid;
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _loadFeed();
    getImage();
    checkPriv();
    checkFollowed();
  }
  checkFollowed()async{
    await getcurrUserDetails();
    var currUser = await FirebaseFirestore.instance
        .collection('users')
        .doc(cuid)
        .get();
    List currLikes = currUser.get('following');
   if( currLikes.contains(widget.userid)){
     setState(() {
       bttntext = "followed";
       colorr = Colors.black;
     });
   }
  }
  DBservice db = DBservice();
  final user = UserPreferences.myUser;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<Post> posts = [
  ];
  bool isPriv = true;
  _follow() async{
    await getcurrUserDetails();
    if (widget.userid != null){
      var check = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: widget.userid)
          .get();
      isPriv = check.docs[0]['isPriv'];
      if (!isPriv){
        await getUserDetails();
        var currUser = await FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .get();
        var currFollowing = currUser.get('following');
        currFollowing.add(widget.userid);
        var collection = FirebaseFirestore.instance.collection('users');
        collection.doc(uid).update({"following" : currFollowing} );

        var otherUser = await FirebaseFirestore.instance
            .collection('users')
            .doc(widget.userid)
            .get();
        var otherFollower = otherUser.get('followers');
        otherFollower.add(uid);
        collection.doc(widget.userid).update({"followers" : otherFollower} );
        db.addFollowNotif('follow', "-", cusername, cuid, widget.userid!, DateTime.now().toString());
        setState(() {
          bttntext = "followed";
          colorr = Colors.black;
        });

      }
      else
        {
          db.addFollowNotif('privFollow', "-", cusername, cuid, widget.userid!, DateTime.now().toString());
          setState(() {
            bttntext = "requested";
            colorr = Colors.black;

          });
        }
    }


  }
  checkPriv()async{
    var check = await FirebaseFirestore.instance
        .collection('users')
        .where('uid', isEqualTo: widget.userid)
        .get();
    isPriv = await check.docs[0]['isPriv'];
    FirebaseAuth _auth;
    User? _user;
    _auth = FirebaseAuth.instance;
    _user = await _auth.currentUser;
    print(_user.toString());
    if (_user != null) {
      print("c  ${_user.uid}");
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: _user.uid)
          .get();
      List currFollow = all.docs[0]['following'];
      if(currFollow.contains(widget.userid))
        {
          isPriv = false;
          setState(() {
            bttntext = "Followed";
          });
        }
    }
    if(!widget.isOther){
      isPriv = false;
    }
  }
  String bttntext = "Follow";
  Color colorr = AppColors.primaryColor;
  void _loadFeed() async {
    print("beforeuser");
    await getUserDetails();
    print("beforepriv");
    await checkPriv();
    print("isOther ${widget.isOther}");
    if(widget.isOther){
      posts = [];
      print("isPriv ${isPriv}");
      if(!isPriv ){
        var all = await FirebaseFirestore.instance
            .collection('users')
            .where('uid', isEqualTo: widget.userid)
            .get();
        var feed_post = await FirebaseFirestore.instance
            .collection('posts')
            .where('uid', isEqualTo: widget.userid)
            .get();
        print("DAAAAAAA");
        feed_post.docs.forEach((doc) =>
        {
          print("b"),
          if (doc['active'] == "active") {
            print("CAAAAAAa"),
            posts.add(
                Post(
                  username: doc['username'],
                  userid: doc['uid'],
                  postPhoto: doc['postPhoto'],
                  text: doc['text'],
                  date: doc['date'],
                  likes: doc['likes'],
                  comments: doc['comments'],
                  topics: doc['topics'],
                  isLiked: doc['likes'].contains(widget.userid) ? true : false,
                  likeCt: doc['likes'].length,
                  active: doc['active'],
                  postid: doc.id,
                )
            )
          }
        });
      }

    }
    else {
      posts = [];
      FirebaseAuth _auth;
      User? _user;
      _auth = FirebaseAuth.instance;
      _user = _auth.currentUser;
      print(_user.toString());
      if (_user != null) {
        print("c  ${_user.uid}");
        var all = await FirebaseFirestore.instance
            .collection('users')
            .where('uid', isEqualTo: _user.uid)
            .get();
        var feed_post = await FirebaseFirestore.instance
            .collection('posts')
            .where('uid', isEqualTo: _user.uid)
            .get();
        print("d");
        feed_post.docs.forEach((doc) =>
        {
          print("b"),
          if (doc['active'] == "active") {
            print("a"),
            posts.add(
                Post(
                  username: doc['username'],
                  userid: doc['uid'],
                  postPhoto: doc['postPhoto'],
                  text: doc['text'],
                  date: doc['date'],
                  likes: doc['likes'],
                  comments: doc['comments'],
                  topics: doc['topics'],
                  isLiked: doc['likes'].contains(_user!.uid) ? true : false,
                  likeCt: doc['likes'].length,
                  active: doc['active'],
                  postid: doc.id,
                )
            )
          }
        });
      }
    }
  }

  String fullname = "a",
      username = "a",
      uid = "a",
      email = "a",
      photo =  'https://images.genius.com/a327ce18ee763752ef342d874a1ba07c.300x300x1.jpg',
      url1 = 'https://images.genius.com/a327ce18ee763752ef342d874a1ba07c.300x300x1.jpg',
      bio = "No bio";
  List followers = ["a"],
      following = ["a"];
  String cfullname = "a",
      cusername = "a",
      activation = "active",
      cuid = "a",
      cemail = "a",
      cphoto =  'https://images.genius.com/a327ce18ee763752ef342d874a1ba07c.300x300x1.jpg',
      curl1 = 'https://images.genius.com/a327ce18ee763752ef342d874a1ba07c.300x300x1.jpg',
      cbio = "No bio";
  List cfollowers = ["a"],
      cfollowing = ["a"];
  Future getImage() async{
    await getUserDetails();
    print("cccc ${photo}");
    if(photo != null) {
      final ref = FirebaseStorage.instance.ref().child('/uploads/${photo}');
      print("asf");
      var url = await ref.getDownloadURL();
      setState(() {
        url1 = url;
        print("AAAAAAAAAAAAAA$url1");
      });

    }
  }
  Future getcurrUserDetails() async {
    User? _user = await _auth.currentUser;
    print(_user.toString());
    if (_user != null) {
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: _user.uid)
          .get();
      print("ca");
      cusername = all.docs[0]['username'];
      cuid = _user.uid;
      cfullname = all.docs[0]['fullname'];
      cemail = all.docs[0]['email'];
      cphoto = all.docs[0]['userPhoto'];
      cfollowers = all.docs[0]['followers'];
      cfollowing = all.docs[0]['following'];
      cbio = all.docs[0]['bio'];
      isPrivDia = all.docs[0]['isPriv'];
      activation = all.docs[0]['active'];

      print(uid);
    }
  }
  bool isPrivDia = false;
  showAlertDialog(BuildContext context) async {

    // set up the button
    Widget okButton = TextButton(
      child: Text("OK"),
      onPressed: () async{
      Navigator.of(context, rootNavigator: true).pop('dialog');},
    );
    print("getcurronce");
    await getcurrUserDetails();
    print("getcurrsonra");
    await getImage();
    print("getim");


    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("PP"),
      content: Center(child: Container( child: Ink.image(
        image: NetworkImage(url1) ,
        fit: BoxFit.cover,
        width: 300,
        height: 200,
        child: InkWell(onTap: (){showAlertDialog(context);}),
      ),),),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  Future getUserDetails() async {
    User? _user = await _auth.currentUser;
    print(_user.toString());
    if (_user != null && !widget.isOther) {
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: _user.uid)
          .get();
      print("ca");
      username = all.docs[0]['username'];
      uid = _user.uid;
      fullname = all.docs[0]['fullname'];
      email = all.docs[0]['email'];
      photo = all.docs[0]['userPhoto'];
      followers = all.docs[0]['followers'];
      following = all.docs[0]['following'];
      bio = all.docs[0]['bio'];

      print(uid);
    }
    if (widget.isOther) {
      print("deneme ${widget.userid}");
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: widget.userid)
          .get();

      print("ca${all.size}");
      print("wico ${widget.userid}");
      print(all.docs[0]['username']);
      username = all.docs[0]['username'];
      print("user");
      uid = widget.userid!;
      fullname = all.docs[0]['fullname'];
      print("name");
      email = all.docs[0]['email'];
      print("email");
      photo = all.docs[0]['userPhoto'];
      print("photo");
      followers = all.docs[0]['followers'];
      print("flwer");
      following = all.docs[0]['following'];
      print("flwing");
      bio = all.docs[0]['bio'];
      print("bio");
      print("tatata");
      print(uid);
    }

  }
  @override
  Widget build(BuildContext context) {

print(photo);
    return MaterialApp(
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(
          leading: BackButton(onPressed: () {
            Navigator.pop(context);
          }),
          backgroundColor: Colors.transparent,
          elevation: 0,
          actions: [
            if(!widget.isOther)
            IconButton(
              onPressed: () async{
                await getcurrUserDetails();
              Navigator.of(context).push(MaterialPageRoute(builder: (context) {
                  return EditProfilePage(analytics: ConnectedFirebase.analytics,
                    observer: ConnectedFirebase.observer,
                    uid: cuid);
              }));},
              icon: Icon(CupertinoIcons.settings_solid),
              color: Colors.white,
            ),
            if(widget.isOther)
              IconButton(
                onPressed: () async{
    await getUserDetails();
    final CollectionReference report = FirebaseFirestore.instance.collection('reporteduser');
    report.add({
      'uid': widget.userid
    });
                },

                icon: Icon(CupertinoIcons.flag),
                color: Colors.white,
              )
          ],
        ),
        body: ListView(
          physics: BouncingScrollPhysics(),
          children: [
                Center(
                child: Stack(
                children: [
                  ClipOval(
                  child: Material(
                  color: Colors.transparent,
                  child: Ink.image(
                    image: NetworkImage(url1) ,
                    fit: BoxFit.cover,
                    width: 128,
                    height: 128,
                    child: InkWell(onTap: (){showAlertDialog(context);}),
                  ),
                )),

              ],
            ),
            ),
            const SizedBox(height: 24),
            Column(
              children: [
                Text(
                  fullname,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                ),
                const SizedBox(height: 4),
                Text(
                  username,
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Column(
              children: [
                Text(
                  bio,
                  style: TextStyle(fontSize: 16, height: 1.4),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
            mainAxisAlignment : MainAxisAlignment.center,
            children: <Widget>[
                    MaterialButton(
                    onPressed: (){
                    },
                    child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                    Text(
                    "${posts.length}",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                    ),
                    SizedBox(height: 2),
                    Text(
                    "Posts",
                    style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    ],
                    ) ,
                    ),
    VerticalDivider(),
              Row(
                  mainAxisAlignment : MainAxisAlignment.center,
                  children: [
                    MaterialButton(
                      onPressed: (){
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "${following.length}",
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                          SizedBox(height: 2),
                          Text(
                            "Following",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ) ,
                    ),]),
    VerticalDivider(),
              Row(
                  mainAxisAlignment : MainAxisAlignment.center,
                  children: [
                    MaterialButton(
                      onPressed: (){
                      },
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            "${followers.length}",
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                          SizedBox(height: 2),
                          Text(
                            "Followers",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ) ,
                    ),]),
    VerticalDivider(),
            ],
            ),
            if(widget.isOther) Row( mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
              ElevatedButton( style: ButtonStyle(minimumSize:  MaterialStateProperty.all<Size>(Size(95, 37)),backgroundColor: MaterialStateProperty.all<Color>(colorr)), onPressed: bttntext=="followed"||bttntext == "requested" ?null: (){_follow();}, child: Text(bttntext, style: TextStyle(color: AppColors.whiteBackground),)),
                ElevatedButton(style: ButtonStyle(minimumSize:  MaterialStateProperty.all<Size>(Size(95, 37)),backgroundColor: MaterialStateProperty.all<Color>(AppColors.dirtybackground)),onPressed: (){}, child: Text("Message", style: TextStyle(color: AppColors.primaryColor),))
              ],),
            const SizedBox(height: 20),
            SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                  left: MediaQuery
                      .of(context)
                      .size
                      .width / 100,
                  right: MediaQuery
                      .of(context)
                      .size
                      .width / 100,
                ),
                child:!isPriv ?
                Column(
                  children: posts
                      .map((post) =>
                      PostTile(
                        post: post, delete: () {
                        posts.remove(post);
                      }, editpost: () {  }, incrementLike: () {  }, isEdit: true && !widget.isOther,

                      ))
                      .toList(),
                ) : Center(child:Text("This profile is private", style: TextStyle(color: Colors.white, fontSize: 20),)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

