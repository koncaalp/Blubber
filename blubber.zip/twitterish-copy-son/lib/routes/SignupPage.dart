import 'package:email_validator/email_validator.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:twitterish/routes/FeedPage.dart';
import 'package:twitterish/services/db.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/dimensions.dart';
import 'package:twitterish/utils/styles.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({Key? key, required this.analytics, required this.observer})
      : super(key: key);
  final FirebaseAnalytics analytics;
  final FirebaseAnalyticsObserver observer;

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  int count = 0;
  String token = "";
  String _message = "";
  String name = "";
  String surname = "";
  DBservice db = DBservice();
  FirebaseAuth _auth = FirebaseAuth.instance;

  void setMessage(String message) {
    setState(() {
      _message = message;
    });
  }

  Future<void> signUpUser() async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);
      db.addUser("$name $surname", email, userCredential.user!.uid, "$name$surname");
      print(userCredential.toString());
    } on FirebaseException catch (e) {
      print(e.toString());
      if (e.code == 'email-already-in-use') {
        setMessage('Email already exists!');
      } else if (e.code == 'weak-password') {
        setMessage('Weak password: add uppercase, lowercase, special char');
      }
    }
  }
  @override
  void initState() {
    super.initState();
    _auth.authStateChanges().listen((event) {
      if (event == null) {
        print('User is signed out!');
      } else {
        print('User is signed in!');
      }
    });
  }
 bool x = true;
  @override
  Widget build(BuildContext context) {
    _auth.authStateChanges().listen((event) {
      if (event == null) {
        setState(() {
          x = true;
        });
      } else {
        setState(() {
          x = false;
        });
      }
    });
    if (x)
      {
        return Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/backgroundImage.jpeg'),
                fit: BoxFit.cover,
              ),
            ),
            child: Scaffold(
              backgroundColor: Colors.transparent,
              body: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 100,
                      ),
                      Container(
                        alignment: Alignment.center,
                        child: Text('Sign Up', style: whiteboldheader),
                      ),
                      SizedBox(
                        height: Dimensions.textboxsizedbox,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: Dimensions.xlargeMargin,
                            right: Dimensions.xlargeMargin),
                        child: Column(
                          children: [
                            Container(
                              alignment: Alignment.centerLeft,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Text('Name', style: whitemedium),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  TextFormField(

                                    onSaved: (value) {
                                      if (value != null) {
                                        name = value;
                                      }
                                    },
                                    keyboardType: TextInputType.name,
                                    style: whiteregular,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderSide:
                                        BorderSide(color: AppColors.border),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(Dimensions.borderRadius),
                                        ),
                                      ),
                                      contentPadding: EdgeInsets.only(
                                          top: Dimensions.regularMargin),
                                      prefixIcon: Icon(
                                        Icons.account_circle_outlined,
                                        color: AppColors.icon,
                                      ),
                                      hintText: 'Enter your name: ',
                                    ),
                                  ),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  Text('Surname', style: whitemedium),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  TextFormField(

                                    onSaved: (value) {
                                      if (value != null) {
                                        surname = value;
                                      }
                                    },
                                    keyboardType: TextInputType.name,
                                    style: whiteregular,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderSide:
                                        BorderSide(color: AppColors.border),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(Dimensions.borderRadius),
                                        ),
                                      ),
                                      contentPadding: EdgeInsets.only(
                                          top: Dimensions.regularMargin),
                                      prefixIcon: Icon(
                                        Icons.account_circle_outlined,
                                        color: AppColors.icon,
                                      ),
                                      hintText: 'Enter your surname: ',
                                    ),
                                  ),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  Text(
                                    'Email',
                                    style: whitemedium,
                                  ),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  TextFormField(
                                    validator: (value) {
                                      if (value == null) {
                                        return 'Email field can not be empty!';
                                      } else {
                                        String trimmedValue = value.trim();
                                        if (trimmedValue.isEmpty) {
                                          return 'Please enter email!';
                                        }
                                        if (!EmailValidator.validate(
                                            trimmedValue)) {
                                          return 'Please enter a valid email!';
                                        }
                                      }
                                      return null;
                                    },
                                    onSaved: (value) {
                                      if (value != null) {
                                        email = value;
                                      }
                                    },
                                    keyboardType: TextInputType.emailAddress,
                                    style: whiteregular,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderSide:
                                        BorderSide(color: AppColors.border),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(Dimensions.borderRadius),
                                        ),
                                      ),
                                      contentPadding: EdgeInsets.only(
                                          top: Dimensions.regularMargin),
                                      prefixIcon: Icon(
                                        Icons.mail,
                                        color: AppColors.icon,
                                      ),
                                      hintText: 'Enter your email: ',
                                    ),
                                  ),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  Text(
                                    'Password',
                                    style: whitemedium,
                                  ),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  TextFormField(
                                    validator: (value) {
                                      if (value == null) {
                                        return 'Password field can not be empty!';
                                      } else {
                                        String trimmedValue = value.trim();
                                        if (trimmedValue.isEmpty) {
                                          return 'Password field can not be empty!';
                                        }
                                        if (trimmedValue.length < 8) {
                                          return 'Password must be longer than 8 characters!';
                                        }
                                      }
                                      return null;
                                    },
                                    onSaved: (value) {
                                      if (value != null) {
                                        password = value;
                                      }
                                    },
                                    keyboardType: TextInputType.name,
                                    style: whiteregular,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderSide:
                                        BorderSide(color: AppColors.border),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(Dimensions.borderRadius),
                                        ),
                                      ),
                                      contentPadding: EdgeInsets.only(
                                          top: Dimensions.regularMargin),
                                      prefixIcon: Icon(
                                        Icons.lock,
                                        color: AppColors.icon,
                                      ),
                                      hintText: 'Enter your password: ',
                                    ),
                                  ),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  Text(
                                    'Password Again',
                                    style: whitemedium,
                                  ),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  TextField(
                                    keyboardType: TextInputType.name,
                                    style: whiteregular,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderSide:
                                        BorderSide(color: AppColors.border),
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(Dimensions.borderRadius),
                                        ),
                                      ),
                                      contentPadding: EdgeInsets.only(
                                          top: Dimensions.regularMargin),
                                      prefixIcon: Icon(
                                        Icons.lock,
                                        color: AppColors.icon,
                                      ),
                                      hintText: 'Enter your password again: ',
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        top: Dimensions.largeMargin),
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 50,
                                      child: ElevatedButton(
                                        child: Text('SIGN UP', style: mainbutton),
                                        style: ButtonStyle(
                                          shape: MaterialStateProperty.all<
                                              RoundedRectangleBorder>(
                                            RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(
                                                  Dimensions.borderRadius),
                                            ),
                                          ),
                                          backgroundColor:
                                          MaterialStateProperty.all<Color>(
                                            AppColors.whiteBackground,
                                          ),
                                        ),
                                        onPressed: () {
                                          if (_formKey.currentState!.validate()) {
                                            _formKey.currentState!.save();
                                          }
                                          signUpUser();
                                        },
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: Dimensions.textboxsizedbox,
                                  ),
                                  Container(
                                    alignment: Alignment.center,
                                    child: Column(
                                      children: [
                                        Text('- OR -', style: whitemedium),
                                        SizedBox(height: 5.0),
                                        Text(
                                          'Sing Up with',
                                          //style: kLabelLightTextStyle,
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: Dimensions.textboxsizedbox),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                    children: <Widget>[
                                      GestureDetector(
                                        onTap: () => print('Sing Up with Facebook'),
                                        child: Container(
                                          height: 40.0,
                                          width: 60.0,
                                          decoration: const BoxDecoration(
                                              shape: BoxShape.circle,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: AppColors.shadow,
                                                  offset:
                                                  Offset(0, Dimensions.offset),
                                                  blurRadius: 6.0,
                                                ),
                                              ],
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      'assets/fb.jpeg'))),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () => print('Sing Up with Google'),
                                        child: Container(
                                          height: 40.0,
                                          width: 60.0,
                                          decoration: const BoxDecoration(
                                              shape: BoxShape.circle,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: AppColors.shadow,
                                                  offset:
                                                  Offset(0, Dimensions.offset),
                                                  blurRadius: 6.0,
                                                ),
                                              ],
                                              image: DecorationImage(
                                                  image: AssetImage(
                                                      'assets/ggl.jpeg'))),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 5.0),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        top: Dimensions.largeMargin * 1.5),
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 50,
                                      child: ElevatedButton(
                                        child: Text('CANCEL', style: mainbutton),
                                        style: ButtonStyle(
                                          shape: MaterialStateProperty.all<
                                              RoundedRectangleBorder>(
                                            RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(
                                                  Dimensions.borderRadius),
                                            ),
                                          ),
                                          backgroundColor:
                                          MaterialStateProperty.all<Color>(
                                            AppColors.dirtybackground,
                                          ),
                                        ),
                                        onPressed: () {
                                          Navigator.pushNamed(
                                              context, '/WelcomePage.dart');
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        );
      }
    else {
      return FeedPage(analytics: widget.analytics, observer: widget.observer);
    }

  }
}
