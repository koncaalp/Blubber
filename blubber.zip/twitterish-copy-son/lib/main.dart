import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twitterish/routes/MyApp.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
   bool ifFirst = false;
  SharedPreferences prefs = await SharedPreferences.getInstance();
  if (prefs.getBool('initial') == null) {
    ifFirst = true;
    await prefs.setBool('initial', true);

  }
  return runApp(MyApp(ifFirst: ifFirst,));
}
