import 'package:twitterish/utils/user.dart';

class UserPreferences {
  static var myUser = user(
    imagePath:
        'https://images.genius.com/a327ce18ee763752ef342d874a1ba07c.300x300x1.jpg',
    name: 'Teoman',
    username: '@teoman',
    bio: 'Paramparça',
    activation: 'active',
    uid: '',

  );
}
