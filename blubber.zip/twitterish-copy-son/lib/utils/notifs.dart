import 'package:flutter/material.dart';

class Notif {
  //Icon usericon;
  String type;
  String ruid;
  String suid;
  String username;
  String content;
  String date;
  String notifid;



  Notif({
    //required this.usericon,
    required this.date,
    required this.ruid,
    required this.suid,
    required this.type,
    required this.username,
    required this.content,
    required this.notifid,
  });

  @override
  String toString() => 'Username: $username\nDate: $date\nType:$type \n Content: $content\n';
}