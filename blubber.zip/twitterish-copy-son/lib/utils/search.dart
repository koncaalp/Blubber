import 'package:flutter/material.dart';

class Search {
  String profile;
  String text;
  String date;
  int likeCt;
  int commentCt;
  String uid;

  Search({
    required this.profile,
    required this.text,
    required this.date,
    required this.likeCt,
    required this.commentCt,
    required this.uid,
  });

  @override
  String toString() =>
      'Profile $profile Post $text\nDate $date\nLikes $likeCt\nComments $commentCt';
}
