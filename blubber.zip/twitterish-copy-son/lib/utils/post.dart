import 'package:flutter/material.dart';

class Post {
  String text;
  String date;
  List? likes;
  String username;
  String userid;
  String? postPhoto;
  List comments;
  List? topics;
  String active;
  bool isLiked;
  int? likeCt;
  int? commentCt;
  String? postid;


  Post({
    required this.text,
     this.postid,
    required this.date,
     this.likes,
    required this.username,
    required this.userid,
     this.postPhoto,
     this.comments =  const ["no comments yet"],
     this.topics,
    required this.active,
     required this.isLiked,
     this.likeCt = 0,

  });

  @override
  String toString() =>
      'Post $text\nDate ';
}
