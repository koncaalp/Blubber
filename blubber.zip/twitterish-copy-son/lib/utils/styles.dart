import 'package:twitterish/utils/colors.dart';
import 'package:flutter/material.dart';

final whiteheader = TextStyle(
  color: AppColors.textwithbackground,
  fontSize: 22.0,
);
final whiteboldheader = TextStyle(
  color: AppColors.textwithbackground,
  fontSize: 28.0,
  fontWeight: FontWeight.w700
);
final whitemedium = TextStyle(
  color: AppColors.textwithbackground,
  fontSize: 18
);
final whiteboldmedium = TextStyle(
    color: AppColors.textwithbackground,
    fontSize: 18,
  fontWeight: FontWeight.bold
);
final whiteregular = TextStyle(
  color: AppColors.textwithbackground,
);

final mainbutton = TextStyle(
  color: Color(0xFF527DAA),
  letterSpacing: 1.5,
  fontSize: 18.0,
  fontWeight: FontWeight.bold,
);
final catchphrase =
    TextStyle(
        fontSize: 30,
        color: Colors.white,
        fontWeight: FontWeight.w900
);