import 'package:cloud_firestore/cloud_firestore.dart';

class user {
  String username;
  String name;
  String imagePath;
  List<dynamic>? followers;
  List<dynamic>? following;
  List<dynamic>? posts;
  String bio;
  String uid;
  String activation;

  user({required this.username,
    required this.name,
    this.followers,
    this.following,
    this.posts,
    required this.bio,
    required this.imagePath,
    required this.uid,
    required this.activation});

  user.fromData(Map<String, dynamic> data)
      : username = data['username'],
        name = data['name'],
        followers = data['followers'],
        following = data['following'],
        posts = data['posts'],
        bio = data['bio'],
        imagePath = data['imagePath'],
        uid = data['uid'],
        activation = data['activation'];

  factory user.fromDocument(DocumentSnapshot doc) {
    return user(
      username: doc['username'],
      name: doc['name'],
      followers: doc['followers'],
      following: doc['following'],
      posts: doc['posts'],
      bio: doc['bio'],
      imagePath: doc['imagePath'],
      uid: doc['uid'],
      activation: doc['activation'],
    );
  }


  Map<String, dynamic> toJson() {
    return {
      'username': username,
      'name': name,
      'followers': followers,
      'following': following,
      'posts': posts,
      'bio': bio,
      'imagePath': imagePath,
      'uid': uid,
      'activation': activation
    };
  }
}


