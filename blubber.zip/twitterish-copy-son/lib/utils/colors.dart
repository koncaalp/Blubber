import 'package:flutter/material.dart';

// For Dark Twitter Open Comments if needed.
/*
class AppColors {
  static const Color primaryColor = const Color(0x1DA1F2); // Twitter blue
  static const Color backgroundColor =
      const Color(0x14171A); // Black background
  static const Color darkGrey =
      const Color(0x657786); // for input field, user id (@jackdorsey) etc.
  static const Color lightGrey =
      const Color(0xF5F8FA); // use this instead of white
}
*/

class AppColors {
  static const Color primaryColor = Colors.blue;
  static const Color secondaryColor = Colors.white;

  static const Color whiteBackground = Colors.white;
  static const Color textwithbackground = Colors.white;
  static const Color dots = Colors.grey;
  static const Color textwobackground = Colors.black;
  static const Color success = Colors.green;
  static const Color logintext = const Color(0xFF527DAA);
  static const Color shadow = Colors.black26;
  static const Color dirtybackground = Colors.white70;
  static const Color border = Colors.white;
  static const Color icon = Colors.white;




//static const Color...
}
