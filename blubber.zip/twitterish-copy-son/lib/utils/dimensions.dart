class Dimensions {
  static const double smallMargin = 5.0;
  static const double regularMargin = 10.0;
  static const double largeMargin = 20.0;
  static const double xlargeMargin = 50.0;
  static const double textboxsizedbox = 10.0;
  static const double borderRadius = 30.0;
  static const double borderWidth = 2.0;

  static const double offset = 2.0;
}
