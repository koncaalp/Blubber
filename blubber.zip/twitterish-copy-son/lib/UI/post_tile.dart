import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:twitterish/routes/FeedPage.dart';
import 'package:twitterish/routes/edit_post.dart';
import 'package:twitterish/services/db.dart';
import 'package:twitterish/utils/post.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/styles.dart';

class PostTile extends StatefulWidget {
  final Post post;
  final bool isEdit;
  final VoidCallback delete;
  final VoidCallback incrementLike;
  final VoidCallback editpost;


  //final VoidCallback updateDB;
  //final  Function(String?) updateLike;


  PostTile({required this.post, required this.delete,
    required this.incrementLike, //required this.updateDB
    required this.editpost, //required this.updateDB
required this.isEdit
  });


  @override
  State<PostTile> createState() => _PostTileState();




}

class _PostTileState extends State<PostTile> {
  String? url1;
  Future getImage() async{
    if(widget.post.postPhoto != null) {
      final ref = FirebaseStorage.instance.ref().child('/uploads/${widget.post.postPhoto}');
      print(ref);
      var url = await ref.getDownloadURL();
      url1 = url;

    }
  }
DBservice db = DBservice();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  var username;
  var uid;

  Future getUserDetails() async {
    User? _user = await _auth.currentUser;
    print(_user.toString());
    if (_user != null) {
      var all = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: _user.uid)
          .get();
      print("ca");
      username = all.docs[0]['username'];
      uid = _user.uid;
      print(uid);
    }
  }
  Future addComment(String? postid) async {
    await getUserDetails();
    var currPost = await FirebaseFirestore.instance
        .collection('posts')
        .doc(postid)
        .get();
    //final CollectionReference notifs = FirebaseFirestore.instance.collection(
    //  'notifications');
    db.addNotif('comment', myController.text, username, uid, currPost.get('uid'), DateTime.now().toString(), widget.post.postid!);
    var currComments = currPost.get('comments');
    var collection = FirebaseFirestore.instance.collection('posts');
    collection
        .doc(postid);
    currComments.add(myController.text);
    currComments.remove("no comments yet");
    myController.clear();
    collection.doc(postid).update({"comments" : currComments} );
    setState(() {
      widget.post.comments = currComments;
    });
  }
  void initState() {
    super.initState();
    getImage();
  }
  void updateLike(String? postid) async {
    await getUserDetails();
    var currPost = await FirebaseFirestore.instance
        .collection('posts')
        .doc(postid)
        .get();
    var currLikes = currPost.get('likes');
    await FirebaseFirestore.instance
        .collection('notifications')
        .doc(postid)
        .delete();



    //print(currLikes[0]);
    bool flag;
    String notID;
    if (currLikes.contains(username)) {
      currLikes.remove(username);
      var collection = FirebaseFirestore.instance.collection('posts');
      print(currLikes);
      collection
          .doc(postid);
      collection.doc(postid).update({"likes" : currLikes} );
      collection
          .doc(postid);
      collection.doc(postid).update({"likeCt" : currLikes.length} );
      setState(() {
        widget.post.likeCt = currLikes.length;
      });

      /*var removeLike = await FirebaseFirestore.instance
          .collection('notifications')
          .where('pid', isEqualTo: postid)
          .get();*/

      /*removeLike.docs.forEach((doc) =>
      {
        if (doc['uid'] == currentUser.uid &&
            doc['otherUid'] == widget.post.userid &&
            doc['notifType'] == "like") {
          notID = doc['notifID'],
          FirebaseFirestore.instance
              .collection('notifications')
              .doc(notID)
              .delete()
              .then((value) => print("Notif Deleted"))
              .catchError((error) => print("Failed to delete notif: $error"))
        }
      });*/
    } else {
      db.addNotif('like', widget.post.text, username, uid, currPost.get('uid'), DateTime.now().toString(), widget.post.postid!);
      print("c ${username}");
      currLikes.add(username);
      var collection = FirebaseFirestore.instance.collection('posts');
      print(currLikes);
      collection
          .doc(postid);
      collection.doc(postid).update({"likes" : currLikes} );
      collection.doc(postid).update({"likeCt" : currLikes.length} );
      setState(() {
        widget.post.likeCt = currLikes.length;
      });

      /*try {
        var notif_ref = notifs.doc();
        await notif_ref.set({
          "uid": currentUser.uid,
          "otherUid": otherUser.uid,
          "notifType": "like",
          "userPhotoURL": otherUser.photoUrl,
          "pid": postid,
          "username": otherUser.username,
          "postPhotoURL": widget.post.postPhotoURL,
          "notifID": notif_ref.id,
        });
      } catch (e) {
        print(e);
      }
      */
    }
  }
  final myController = TextEditingController();
  final myController3 = TextEditingController();
  deletePost() async {
    await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.post.postid)
        .delete();
    widget.delete();
  }
  showAlertDialog(BuildContext context) {

    // set up the button
    Widget okButton = TextButton(
      child: Text("OK"),
      onPressed: () async{if (myController3.text != null){
        await FirebaseFirestore.instance
            .collection('posts')
            .doc(widget.post.postid)
            .update(
            {'text': myController3.text});
        widget.post.text = myController3.text;
      }
        Navigator.of(context, rootNavigator: true).pop('dialog');},
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("My title"),
      content: TextField(controller: myController3,),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
  @override
  Widget build(BuildContext context) {
    return Card(
      shadowColor: AppColors.primaryColor,
      elevation: 8,
      margin: EdgeInsets.all(8),
      child: Padding(
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 0, 0, 20),
              child: Row(
                children: [
                  Text(widget.post.username, style: TextStyle(color: AppColors.primaryColor, fontSize: 18),),

                ]
              ),
            ),
            Wrap(
              //mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: Text(
                    widget.post.text,
                  ),
                ),
                SizedBox(width: 150),
                if(widget.isEdit)
                  IconButton(onPressed: ()async {
                    showAlertDialog(context);


                  },
                      icon: Icon(Icons.edit)),

                if(!widget.isEdit)
                  SizedBox(height: 15,width:120),
                if(!widget.isEdit)
                    IconButton(
                      onPressed: () async{
                        await getUserDetails();
                        final CollectionReference report = FirebaseFirestore.instance.collection('reportedpost');
                        report.add({
                          'pid': widget.post.postid
                        });
                      },

                      icon: Icon(Icons.flag),
                      color: Colors.white,
                    ),
                if(widget.isEdit)
                  IconButton(onPressed: () {deletePost();} ,icon:  Icon(Icons.delete)),

              ],
            ),
            Container(child: url1 != null
                ? Image.network(url1!): Text("")),
            Row(
              children: [
                Text(
                  widget.post.date.toString(),
                ),
                Spacer(),
                IconButton(
                  splashRadius: 20,
                  icon: Icon(
                    Icons.thumb_up_alt_outlined,
                    color: AppColors.primaryColor,
                  ),
                  onPressed:(){//widget.updateLike(widget.post.postid),
                  updateLike(widget.post.postid); }



                ),
                Text(
                  '${widget.post.likeCt}',
                ),
                SizedBox(
                  width: 8,
                ),

              ],
            ),
            //Divider(color: AppColors.primaryColor,thickness: 2, height: 1,),
            Text("Comments" ,style: TextStyle(color:Colors.white)),
            Container(
              height: widget.post.comments.length*30,
              child: ListView.builder(
                  padding: const EdgeInsets.all(0),
                  itemCount: widget.post.comments.length,
                  itemBuilder: (BuildContext context, int index) {

                      return Container(
                        height: 30,
                        child: Center(child: Text('${widget.post.comments[index]}')),
                      );


                  }
              ),
            ),
            Wrap(

                children: [
                  TextField(
                    controller: myController,

                  ),
                  IconButton(onPressed: (){addComment(widget.post.postid);}, icon: Icon(Icons.add))
                ],
              ),

          ],
        ),
      ),
    );
  }
}
