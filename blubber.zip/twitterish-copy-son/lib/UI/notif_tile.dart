import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:twitterish/services/db.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/notifs.dart';

class NotifTile extends StatelessWidget {
  final Notif notif;
  final VoidCallback delete;

   NotifTile({
    required this.notif,
    required this.delete,
  });
  final DBservice db = DBservice();
  deleteNotif(String pid) async{
    FirebaseFirestore.instance
        .collection("notifications")
        .doc(pid)
        .delete();
  }
  acceptReq() async{
    var currUser = await FirebaseFirestore.instance
        .collection('users')
        .doc(notif.suid)
        .get();
    var currFollowing = currUser.get('following');
    currFollowing.add(notif.ruid);
    var collection = FirebaseFirestore.instance.collection('users');
    collection.doc(notif.suid).update({"following" : currFollowing} );

    var otherUser = await FirebaseFirestore.instance
        .collection('users')
        .doc(notif.ruid)
        .get();
    var otherFollower = otherUser.get('followers');
    otherFollower.add(notif.suid);
    collection.doc(notif.ruid).update({"followers" : otherFollower} );
    print(notif.notifid);
    await deleteNotif(notif.notifid);
    delete();
  }
  @override
  Widget build(BuildContext context) {
    if (notif.type == "like") {
      return Card(
        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.lightBlueAccent, width: 0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        shadowColor: Colors.lightBlueAccent,
        elevation: 7,
        color: Colors.black,
        margin: EdgeInsets.symmetric(vertical: 8),
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Icon(Icons.favorite, color: Colors.red, size: 17),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text(notif.username,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 10.0,
                            color: Colors.white)),
                  ),
                  SizedBox(width: 6),
                  Text("liked your Blub",
                      style: TextStyle(fontSize: 10.0, color: Colors.white)),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 0),
                    child: Text(notif.date,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 8.0,
                            color: Colors.grey)),
                  ),
                ],
              ),
              Row(
                children: [
                  SizedBox(width: 27),
                  Text(notif.content, style: TextStyle(color: Colors.grey)),
                  Spacer(),

                  /*
                Icon(
                  Icons.thumb_up,
                  color: AppColors.primaryColor,
                  size: 14,
                ),
                Text(
                  ' x ${post.likeCount}',
                  style: kSubtitleLabel,
                ),
                 */

                  SizedBox(height: 30,)
                ],
              ),
            ],
          ),
        ),
      );
    }
    else if (notif.type == "comment") {
      return Card(
        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.lightBlueAccent, width: 0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        shadowColor: Colors.lightBlueAccent,
        elevation: 7,
        color: Colors.black,
        margin: EdgeInsets.symmetric(vertical: 8),
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Icon(Icons.comment, color: Colors.white, size: 17),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text(notif.username,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 10.0,
                            color: Colors.white)),
                  ),
                  SizedBox(width: 6),
                  Text("commented on your Blub",
                      style: TextStyle(fontSize: 10.0, color: Colors.white)),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 0),
                    child: Text(notif.date,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 8.0,
                            color: Colors.grey)),
                  ),
                ],
              ),
              Row(
                children: [
                  SizedBox(width: 27),
                  Text(notif.content, style: TextStyle(color: Colors.white)),
                  Spacer(),

                  /*
                Icon(
                  Icons.thumb_up,
                  color: AppColors.primaryColor,
                  size: 14,
                ),
                Text(
                  ' x ${post.likeCount}',
                  style: kSubtitleLabel,
                ),
                 */

                  SizedBox(height: 30,)
                ],
              ),
            ],
          ),
        ),
      );
    }
    else if (notif.type == "follow") {
      return Card(
        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.lightBlueAccent, width: 0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        shadowColor: Colors.lightBlueAccent,
        elevation: 7,
        color: Colors.black,
        margin: EdgeInsets.symmetric(vertical: 8),
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Icon(Icons.supervised_user_circle_outlined, color: Colors.white, size: 17),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text(notif.username,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 12.0,
                            color: Colors.white)),
                  ),
                  SizedBox(width: 6),
                  Text("followed you",
                      style: TextStyle(fontSize: 12.0, color: Colors.white)),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 0),
                    child: Text(notif.date,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 8.0,
                            color: Colors.grey)),
                  ),
                ],
              ),
              Row(
                children: [
                  SizedBox(width: 27),
                  Text("", style: TextStyle(color: Colors.grey)),
                  Spacer(),

                  /*
                Icon(
                  Icons.thumb_up,
                  color: AppColors.primaryColor,
                  size: 14,
                ),
                Text(
                  ' x ${post.likeCount}',
                  style: kSubtitleLabel,
                ),
                 */

                  SizedBox(height: 30,)
                ],
              ),
            ],
          ),
        ),
      );
    }
    else if (notif.type == "privFollow") {
      return Card(
        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.lightBlueAccent, width: 0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        shadowColor: Colors.lightBlueAccent,
        elevation: 7,
        color: Colors.black,
        margin: EdgeInsets.symmetric(vertical: 8),
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Icon(Icons.supervised_user_circle_rounded, color: Colors.white, size: 17),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text(notif.username,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 12.0,
                            color: Colors.white)),
                  ),
                  SizedBox(width: 6),
                  Text("requested to follow you",
                      style: TextStyle(fontSize: 12.0, color: Colors.white)),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 0),
                    child: Text(notif.date,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 8.0,
                            color: Colors.grey)),
                  ),
                ],
              ),
              Row(
                children: [
                  SizedBox(width: 27),
                  Text("Do you want to accept?", style: TextStyle(color: Colors.white)),
                  Spacer(),

                  /*
                Icon(
                  Icons.thumb_up,
                  color: AppColors.primaryColor,
                  size: 14,
                ),
                Text(
                  ' x ${post.likeCount}',
                  style: kSubtitleLabel,
                ),
                 */

                  ElevatedButton( style: ButtonStyle(minimumSize:  MaterialStateProperty.all<Size>(Size(95, 37)),backgroundColor: MaterialStateProperty.all<Color>(AppColors.primaryColor)), onPressed: (){acceptReq();}, child: Text("Accept", style: TextStyle(color: AppColors.whiteBackground),)),

                ],
              ),
            ],
          ),
        ),
      );
    }

    else {
      return Card(

        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.lightBlueAccent, width: 0.6),
          borderRadius: BorderRadius.circular(10),
        ),
        shadowColor: Colors.lightBlueAccent,
        elevation: 7,
        color: Colors.black,
        margin: EdgeInsets.symmetric(vertical: 8),
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Icon(Icons.autorenew,
                      color: Colors.lightGreenAccent, size: 19),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text(notif.username,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 10.0,
                            color: Colors.white)),
                  ),
                  SizedBox(width: 6),
                  Text("reshared",
                      style: TextStyle(fontSize: 10.0, color: Colors.white)),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 0),
                    child: Text(notif.date,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 8.0,
                            color: Colors.grey)),
                  ),
                ],
              ),
              Row(
                children: [
                  SizedBox(width: 29),
                  Text(notif.content, style: TextStyle(color: Colors.white)),
                  Spacer(),

                  /*
                Icon(
                  Icons.thumb_up,
                  color: AppColors.primaryColor,
                  size: 14,
                ),
                Text(
                  ' x ${post.likeCount}',
                  style: kSubtitleLabel,
                ),
                 */

                  SizedBox(height: 30,)
                ],
              ),
            ],
          ),
        ),
      );
    }
  }
}
