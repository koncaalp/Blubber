import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:twitterish/utils/post.dart';
import 'package:twitterish/utils/colors.dart';
import 'package:twitterish/utils/styles.dart';

class UserPostTile extends StatefulWidget {
  final Post post;
  final VoidCallback delete;


  const UserPostTile(
      {required this.post, required this.delete,
      });

  @override
  State<UserPostTile> createState() => _UserPostTileState();
}

class _UserPostTileState extends State<UserPostTile> {
  String? url1;
  Future getImage() async{
    if(widget.post.postPhoto != null) {
      final ref = FirebaseStorage.instance.ref().child('/uploads/${widget.post.postPhoto}');
      print(ref);
      var url = await ref.getDownloadURL();
      url1 = url;

    }
  }

  void initState() {
    super.initState();
    getImage();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shadowColor: AppColors.primaryColor,
      elevation: 8,
      margin: EdgeInsets.all(8),
      child: Padding(
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(
                widget.post.text,
              ),
            ),
            Container(child: url1 != null
                ? Image.network(url1!): Text("")),
            Row(
              children: [
                Text(
                  widget.post.date.toString(),
                ),
                Spacer(),

                Text(
                  '${widget.post.likeCt}',
                ),
                SizedBox(
                  width: 8,
                ),

              ],
            ),
          ],
        ),
      ),
    );
  }
}
