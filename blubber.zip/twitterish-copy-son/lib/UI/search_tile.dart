import 'package:flutter/material.dart';
import 'package:twitterish/routes/MyApp.dart';
import 'package:twitterish/routes/UserProfilePage.dart';
import 'package:twitterish/utils/search.dart';
import 'package:twitterish/utils/colors.dart';

class SearchTile extends StatelessWidget {
  final Search search;

  const SearchTile({required this.search});

  @override
  Widget build(BuildContext context) {
    return Card(
      shadowColor: AppColors.primaryColor,
      elevation: 8,
      margin: EdgeInsets.all(8),
      child: Padding(
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(
                search.profile,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(
                search.text,
              ),
            ),
            Row(
              children: [
                Text(
                  search.date,
                ),
                Spacer(),


                ElevatedButton( style: ButtonStyle(minimumSize:  MaterialStateProperty.all<Size>(Size(95, 37)),backgroundColor: MaterialStateProperty.all<Color>(AppColors.primaryColor)), onPressed: (){Navigator.of(context).push(MaterialPageRoute(builder: (context) {
                  return ProfilePage(isOther: true, analytics: ConnectedFirebase.analytics, observer: ConnectedFirebase.observer,userid: search.uid,);
                }));}, child: Text("Go to Profile", style: TextStyle(color: AppColors.whiteBackground),)),

              ],
            ),
          ],
        ),
      ),
    );
  }
}
