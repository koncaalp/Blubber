import 'package:cloud_firestore/cloud_firestore.dart';

class DBservice {
  final CollectionReference postCollection = FirebaseFirestore.instance.collection('posts');
  Future addPost(String username, List topics,List likes, String text,String postPhoto, String date, int likeCt,List comments,int commentCt, String active, String uid) async {
    postCollection.add({
      'username' : username,
      'topics': topics,
      'uid': uid,
      'comments': comments,
      'text' : text,
      'postPhoto' : postPhoto,
      'date': date,
      'commentCt': commentCt,
      'active' : active,
      'likeCt' : likeCt,
      'likes' : likes,
    }).then((value) => print("Post Added"))
        .catchError((error) => print("Failed to add user: $error"));
  }
  final CollectionReference userCollection = FirebaseFirestore.instance.collection('users');
  Future addUser(String name, String email, String uid, String username) async {
    userCollection.doc(uid).set({
      'fullname' : name,
      'username': username,
      'email': email,
      'uid': uid,
      'following': [],
      'followers': [],
      'isPriv': true,
      'bio': "No Bio Yet",
      'userPhoto': "-",
      'active': "active",
    }).then((value) => print("User Added"))
        .catchError((error) => print("Failed to add user: $error"));
  }
  final CollectionReference notification = FirebaseFirestore.instance.collection('notifications');
  Future addNotif(String type, String content, String username, String suid, String ruid, String date, String postid) async {
    notification.doc(postid).set({
      'type' : type,
      'content': content,
      'username': username,
      'suid' : suid,
      'ruid' : ruid,
      'date' : date,
      'pid' : postid,

    }).then((value) => print("Notification Added"))
        .catchError((error) => print("Failed to add notification: $error"));
  }
  Future addFollowNotif(String type, String content, String username, String suid, String ruid, String date) async {
    notification.add({
      'type' : type,
      'content': content,
      'username': username,
      'suid' : suid,
      'ruid' : ruid,
      'date' : date,
      'pid' : notification.doc().id,
    }).then((docRef){
      docRef.update({'pid' : docRef.id});
    })
        .catchError((error) => print("Failed to add notification: $error"));
  }

}